package com.example.pangorushbot

enum class BotStatus { STOPPED, RUNNING, PAUSED }

object BotState {
    @Volatile var status = BotStatus.STOPPED
    @Volatile var jumpDelayMs: Int = 120
    @Volatile var sensitivity: Float = 0.55f
    @Volatile var captureResultCode: Int = 0
    @Volatile var captureData: android.content.Intent? = null
}
