package com.example.pangorushbot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

class BotAccessibilityService : AccessibilityService() {

    companion object {
        var instance: BotAccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Здесь будет подключён анализ кадров Pango Rush.
        // Пока сервис только принимает команды состояния и умеет выполнять прыжок.
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    fun jump() {
        if (BotState.status != BotStatus.RUNNING) return

        val dm = resources.displayMetrics
        // Center-bottom area — typical tap zone for endless runners
        val x = dm.widthPixels * 0.50f
        val y = dm.heightPixels * 0.78f

        val path = Path()
        path.moveTo(x, y)
        // tiny movement makes the gesture more reliable on some devices
        path.lineTo(x + 2f, y + 2f)

        val gesture = GestureDescription.Builder()
            .addStroke(
                GestureDescription.StrokeDescription(
                    path,
                    0,
                    60
                )
            )
            .build()

        dispatchGesture(gesture, null, null)
    }
}
