package com.example.pangorushbot

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.SeekBar
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var status: TextView
    private val captureRequest = 7001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.status)

        findViewById<Button>(R.id.startButton).setOnClickListener {
            if (BotAccessibilityService.instance == null) {
                status.text = "Сначала включи Accessibility"
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                return@setOnClickListener
            }
            BotState.status = BotStatus.RUNNING
            updateStatus()
            if (BotState.captureData == null) {
                val pm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(pm.createScreenCaptureIntent(), captureRequest)
            } else startCaptureService()
        }
        findViewById<Button>(R.id.pauseButton).setOnClickListener { if (BotState.status == BotStatus.RUNNING) { BotState.status = BotStatus.PAUSED; updateStatus() } }
        findViewById<Button>(R.id.resumeButton).setOnClickListener { if (BotState.status == BotStatus.PAUSED) { BotState.status = BotStatus.RUNNING; updateStatus() } }
        findViewById<Button>(R.id.stopButton).setOnClickListener { BotState.status = BotStatus.STOPPED; stopService(Intent(this, CaptureService::class.java)); updateStatus() }
        findViewById<Button>(R.id.accessButton).setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        findViewById<Button>(R.id.testJumpButton).setOnClickListener {
            val svc = BotAccessibilityService.instance
            if (svc == null) {
                status.text = "Accessibility НЕ подключён!"
            } else {
                // temporarily force RUNNING so jump() is allowed
                val prev = BotState.status
                BotState.status = BotStatus.RUNNING
                svc.jump()
                BotState.status = prev
                status.text = "Тестовый прыжок отправлен"
            }
        }

        findViewById<SeekBar>(R.id.delayBar).setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { BotState.jumpDelayMs = p; findViewById<TextView>(R.id.delayValue).text = "$p мс" }
            override fun onStartTrackingTouch(s: SeekBar?) {}; override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        findViewById<SeekBar>(R.id.sensitivityBar).setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { BotState.sensitivity = p / 100f; findViewById<TextView>(R.id.sensitivityValue).text = "$p%" }
            override fun onStartTrackingTouch(s: SeekBar?) {}; override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        updateStatus()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureRequest && resultCode == RESULT_OK && data != null) {
            BotState.captureResultCode = resultCode
            BotState.captureData = data
            startCaptureService()
        } else { BotState.status = BotStatus.STOPPED; updateStatus() }
    }

    private fun startCaptureService() {
        val i = Intent(this, CaptureService::class.java).apply {
            putExtra("code", BotState.captureResultCode)
            putExtra("data", BotState.captureData)
        }
        startForegroundService(i)
    }
    private fun updateStatus() { status.text = when (BotState.status) { BotStatus.RUNNING -> "● Запущен"; BotStatus.PAUSED -> "Ⅱ Пауза"; BotStatus.STOPPED -> "■ Остановлен" } }
}
