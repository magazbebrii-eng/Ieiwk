package com.example.pangorushbot

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

object ScreenAnalyzer {
    data class Decision(
        val jump: Boolean,
        val confidence: Float,
        val obstacleDistance: Float,
        val obstacleHeight: Float,
        val playerY: Float
    )

    private var previous: Bitmap? = null
    private var threatFrames = 0
    private var lastPlayerY = 0f

    @Synchronized
    fun reset() {
        previous?.recycle()
        previous = null
        threatFrames = 0
        lastPlayerY = 0f
    }

    @Synchronized
    fun decide(bitmap: Bitmap, sensitivity: Float): Decision {
        val w = bitmap.width
        val h = bitmap.height
        if (w < 200 || h < 200) return Decision(false, 0f, 1f, 0f, 0f)

        // Смотрим только нижнюю игровую зону (где бежит персонаж и препятствия)
        // Игнорируем верх (текст, HUD, кнопки)
        val y0 = (h * 0.55f).toInt()
        val y1 = (h * 0.90f).toInt()
        val x0 = (w * 0.25f).toInt()
        val x1 = (w * 0.85f).toInt()

        val stride = max(6, w / 140)

        // Ищем пол / линию персонажа
        var bestBand = y1 - (h * 0.10f).toInt()
        var bestEnergy = 0f
        for (y in y0 until y1 step stride) {
            var e = 0f
            var n = 0
            for (x in x0 until x1 step stride) {
                val a = luminance(bitmap.getPixel(x, y))
                val b = luminance(bitmap.getPixel(x, min(y + stride, h - 1)))
                e += abs(a - b)
                n++
            }
            val energy = if (n == 0) 0f else e / n
            if (energy > bestEnergy) {
                bestEnergy = energy
                bestBand = y
            }
        }
        val playerY = bestBand.toFloat() / h
        lastPlayerY = if (lastPlayerY == 0f) playerY else lastPlayerY * 0.7f + playerY * 0.3f

        // Ищем препятствия только впереди персонажа
        val startX = (w * 0.48f).toInt()
        val endX = (w * 0.82f).toInt()
        val floorY = (h * max(0.62f, min(0.88f, lastPlayerY + 0.08f))).toInt()

        var bestThreat = 0f
        var bestDist = 1f
        var bestHeight = 0f

        for (x in startX until endX step stride) {
            val colWidth = min(stride * 2, endX - x)
            var occupied = 0
            var samples = 0
            var topHit = h
            var bottomHit = 0

            for (xx in x until x + colWidth) {
                for (y in y0 until min(floorY, y1) step stride) {
                    val p = bitmap.getPixel(xx, y)
                    val r = (p shr 16) and 255
                    val g = (p shr 8) and 255
                    val b = p and 255
                    val lum = (r + g + b) / 765f
                    val chroma = (max(r, max(g, b)) - min(r, min(g, b))) / 255f

                    // Более строгие условия — только заметные объекты
                    val hit = (chroma > 0.28f && lum < 0.75f) || lum < 0.15f
                    if (hit) {
                        occupied++
                        topHit = min(topHit, y)
                        bottomHit = max(bottomHit, y)
                    }
                    samples++
                }
            }

            if (samples == 0) continue
            val density = occupied.toFloat() / samples
            val height = if (bottomHit > topHit) (bottomHit - topHit).toFloat() / h else 0f

            // Более жёсткие требования к препятствию
            val minDensity = 0.09f - sensitivity * 0.03f
            val minHeight = 0.045f
            val plausible = density > minDensity && height > minHeight

            if (plausible) {
                val distance = (x - startX).toFloat() / (endX - startX)
                val proximity = 1f - distance
                val score = density * 1.6f + height * 1.1f + proximity * 0.5f
                if (score > bestThreat) {
                    bestThreat = score
                    bestDist = distance
                    bestHeight = height
                }
            }
        }

        // Нужно больше подтверждений, чтобы не прыгать на мелочи
        val trigger = 0.28f + (1f - sensitivity) * 0.12f
        val closeEnough = bestDist < (0.42f + sensitivity * 0.12f)

        if (bestThreat > trigger && closeEnough) {
            threatFrames++
        } else {
            threatFrames = max(0, threatFrames - 2)
        }

        // Требуем минимум 3 кадра подряд
        val jump = threatFrames >= 3
        val confidence = min(1f, bestThreat / 0.75f)

        return Decision(jump, confidence, bestDist, bestHeight, lastPlayerY)
    }

    private fun luminance(pixel: Int): Float {
        val r = (pixel shr 16) and 255
        val g = (pixel shr 8) and 255
        val b = pixel and 255
        return (0.2126f * r + 0.7152f * g + 0.0722f * b) / 255f
    }
}
