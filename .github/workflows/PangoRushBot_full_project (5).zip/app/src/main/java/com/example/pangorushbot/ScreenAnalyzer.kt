package com.example.pangorushbot

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

object ScreenAnalyzer {
    data class Decision(
        val jump: Boolean,
        val confidence: Float,
        val obstacleDistance: Float,
        val obstacleHeight: Float,
        val playerY: Float
    )

    private var threatFrames = 0
    private var lastPlayerY = 0.75f
    private var calmFrames = 0

    @Synchronized
    fun reset() {
        threatFrames = 0
        lastPlayerY = 0.75f
        calmFrames = 0
    }

    @Synchronized
    fun decide(bitmap: Bitmap, sensitivity: Float): Decision {
        val w = bitmap.width
        val h = bitmap.height
        if (w < 200 || h < 200) return Decision(false, 0f, 1f, 0f, lastPlayerY)

        // Игровая дорожка — узкая полоса внизу, где бежит персонаж и лежат бочки
        val roadTop = (h * 0.62f).toInt()
        val roadBottom = (h * 0.86f).toInt()
        val left = (w * 0.30f).toInt()
        val right = (w * 0.88f).toInt()

        val stride = max(5, w / 160)

        // Ищем ближайшую бочку (низкий объект на дороге)
        var bestThreat = 0f
        var bestDist = 1f
        var bestHeight = 0f
        var found = false

        // Смотрим колонками слева направо (от персонажа вперёд)
        val startX = (w * 0.42f).toInt()
        val endX = (w * 0.85f).toInt()

        for (x in startX until endX step stride) {
            var darkPixels = 0
            var total = 0
            var topY = roadBottom
            var bottomY = roadTop

            for (y in roadTop until roadBottom step stride) {
                val p = bitmap.getPixel(x, y)
                val r = (p shr 16) and 255
                val g = (p shr 8) and 255
                val b = p and 255
                val lum = (r + g + b) / 765f

                // Бочки обычно коричневые / тёмные
                val isBrownish = r > 60 && r > g && r > b && lum < 0.55f
                val isDark = lum < 0.28f

                if (isBrownish || isDark) {
                    darkPixels++
                    if (y < topY) topY = y
                    if (y > bottomY) bottomY = y
                }
                total++
            }

            if (total == 0) continue

            val density = darkPixels.toFloat() / total
            val heightRatio = (bottomY - topY).toFloat() / h

            // Бочка: средняя плотность + небольшая высота (не здание)
            val isBarrelLike = density > (0.12f - sensitivity * 0.04f) &&
                    heightRatio in 0.03f..0.14f

            if (isBarrelLike) {
                val distance = (x - startX).toFloat() / (endX - startX + 1)
                val score = density * 2.0f + (1f - distance) * 1.2f + heightRatio * 0.8f

                if (score > bestThreat) {
                    bestThreat = score
                    bestDist = distance
                    bestHeight = heightRatio
                    found = true
                }
            }
        }

        // Более строгий триггер
        val trigger = 0.35f + (1f - sensitivity) * 0.15f
        val closeEnough = bestDist < 0.55f

        if (found && bestThreat > trigger && closeEnough) {
            threatFrames++
            calmFrames = 0
        } else {
            threatFrames = max(0, threatFrames - 1)
            calmFrames++
        }

        // Требуем 4 кадра подряд подтверждения + не прыгаем слишком часто
        val jump = threatFrames >= 4 && calmFrames < 8

        return Decision(
            jump = jump,
            confidence = min(1f, bestThreat / 0.8f),
            obstacleDistance = bestDist,
            obstacleHeight = bestHeight,
            playerY = lastPlayerY
        )
    }
}
