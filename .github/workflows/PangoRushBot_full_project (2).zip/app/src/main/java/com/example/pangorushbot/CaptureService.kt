package com.example.pangorushbot

import android.app.*
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import java.nio.ByteBuffer

class CaptureService : Service() {
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var lastJump = 0L
    private var lastDecision = 0L

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(42, Notification.Builder(this, "pango_bot")
            .setContentTitle("Pango Rush Bot")
            .setContentText("Анализ экрана активен")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        if (projection == null) {
            val code = intent?.getIntExtra("code", 0) ?: 0
            val data = intent?.getParcelableExtra<Intent>("data") ?: return START_NOT_STICKY
            val pm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = pm.getMediaProjection(code, data)
            startCapture()
        }
        return START_STICKY
    }

    private fun startCapture() {
        val dm = resources.displayMetrics
        val width = dm.widthPixels
        val height = dm.heightPixels
        val density = dm.densityDpi
        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        display = projection?.createVirtualDisplay("PangoRushCapture", width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader?.surface, null, null)
        reader?.setOnImageAvailableListener({ r ->
            if (BotState.status != BotStatus.RUNNING) { r.acquireLatestImage()?.close(); return@setOnImageAvailableListener }
            val image = r.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                val plane = image.planes[0]
                val buffer: ByteBuffer = plane.buffer
                val pixelStride = plane.pixelStride
                val rowStride = plane.rowStride
                val rowPadding = rowStride - pixelStride * width
                val full = Bitmap.createBitmap(width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888)
                buffer.rewind()
                full.copyPixelsFromBuffer(buffer)
                val bitmap = if (full.width != width) Bitmap.createBitmap(full, 0, 0, width, height) else full
                val d = ScreenAnalyzer.decide(bitmap, BotState.sensitivity)
                val now = System.currentTimeMillis()
                lastDecision = now
                // Adaptive cooldown: close/high threats can be acted on sooner,
                // while distant detections are suppressed to avoid double jumps.
                val adaptiveCooldown = when {
                    d.obstacleDistance < 0.22f -> 180L
                    d.obstacleDistance < 0.38f -> 220L
                    else -> 300L
                }
                val cooldown = maxOf(adaptiveCooldown, BotState.jumpDelayMs.toLong())
                if (d.jump && now - lastJump > cooldown) {
                    lastJump = now
                    BotAccessibilityService.instance?.jump()
                }
                if (bitmap !== full) bitmap.recycle()
                full.recycle()
            } finally { image.close() }
        }, Handler(Looper.getMainLooper()))
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel("pango_bot", "Pango Rush Bot", NotificationManager.IMPORTANCE_LOW))
        }
    }

    override fun onDestroy() {
        ScreenAnalyzer.reset()
        reader?.close(); display?.release(); projection?.stop()
        reader = null; display = null; projection = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?) = null
}
